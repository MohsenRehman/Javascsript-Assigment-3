//Additon
let a = 10;
b = 20;
console.log(a+b);

// // subtraction
let c=50;
d = 19;
console.log(c-d);

// // Multiplication
let m = 10;
j=10;
console.log(m*j);

// // Division
let k =50;
l = 9;
console.log(k/l);

// // Modulus
let h = 89;
u = 6;
console.log(h%u);

// uniray operator that not allow to  divion increment and decrement
// so we use the assigment operaor.

// eqal 
let eq =10;
eq = 12;
console.log(eq);

// Addition
let add = 22;
add += 10;
console.log(add);

// Subtraction
let sub = 100;
sub -= 99;
console.log(sub);

// multiplication
let mu= 2;
mu*=3;
console.log(mu);

// divide
let Len=8;
Len/=2
console.log(Len);

// Modulus
let io=5;
io%=2;
console.log(io);


//  Comparison Operators
// Equal to
let age = 18;
length = 15;
console.log(age == length);
//they return false because the value of two variable are not same so they return false and double equal only check the values

let fage = 10;
let lname ='10'
console.log(fage === lname);
//they return false because the value is same but the data type is not same and triple equal check the value as well as data type.

// not equal to
let no = 10;
let tt = 5;
console.log(no != tt); // true

// Greater than
let grea1 = 18;
grea2 = 15;
console.log(grea1 > grea2);

// smaller than
let small1 = 10;
let small2 = 25;
console.log(small1 < small2);

// Greater than or equal to 
let goe1 = 18;
let goe2 =15;
console.log(goe1>=goe2);

// less than or equal to 
let less1 = 19;
let less2 =25;
console.log(less1 <= less2);


//  Expressions
let pen = 10;
let pincile = 5;
let sum = pen + pincile;
console.log(sum);

//Multiplication
let price = 100;
let quantity = 2;
let total = price * quantity;
console.log(total);




// Pratice Task
let num = 10;      // number
let str = "10";   // string

// Using == double equlal.
console.log(num == str); 
// true  because == doest not check the data type only compare the value

// Using === triple equal
console.log(num === str); 
// false  because === equal check the datatype as well as the value.

let checknum = "Khan";
let checkstring = "Khan"
console.log(checknum === checkstring);
//true beacuse using triple equal they check the datatype and the datatype are same so they return true.








